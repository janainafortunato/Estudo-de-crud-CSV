<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Formulario de cadastro</title>
</head>
<body>
	<div>
		<form action="add.php" method="post">
			Nome:
			<input type="text" name="name" placeholder="Nome">
			Idade:
			<input type="text" name="idade" placeholder="Idade">
			País:
			<input type="text" name="pais" placeholder="País">
			<input type="submit" value="Submit">
		</form>
	</div>

</body>
</html>