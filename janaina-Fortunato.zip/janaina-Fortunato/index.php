<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Informações de Usuarios</title>
</head>
<body>

	<?php 	 		

		$resultad = file('arq.csv');
		sort($resultad);
		$conteudo = implode("", $resultad);
		file_put_contents('arq.csv', $conteudo);

?>

	<h1>Informações de Usuarios</h1>
	 <table>
	 	
		<?php for ($i=0;$i<sizeof($resultad);$i++) { ?>
			<tr>
				<th><?php echo $resultad[$i]; ?></th>
			</tr>
		<?php } ?>
	</table>
</body>
</html>