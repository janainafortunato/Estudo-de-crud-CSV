<?php 

$name = $_POST['name'];
$idade = $_POST['idade'];
$pais = $_POST['pais'];
$dados = $name  . "   -  "  .  $idade  . "   -   " .  $pais;

$conteudo = file('arq.csv');

$conteudo[] = $dados . "\n";

$resultad = implode( ' ' , $conteudo);

file_put_contents('arq.csv', $resultad);

header("Location: index.php");
die();

?>